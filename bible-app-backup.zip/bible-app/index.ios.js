import React, { AppRegistry } from 'react-native';

import bible from './index.js';

AppRegistry.registerComponent('bible', () => bible);