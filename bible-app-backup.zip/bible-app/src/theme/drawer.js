export default drawer = {
    drawer: {
    	backgroundColor: '#fff',
    	shadowColor: '#000',
    	shadowOpacity: 0.8,
    	shadowRadius: 3
    },
    main: {
    	paddingLeft: 3,
        backgroundColor:'#000'
    },
    itemText: {
    	fontSize: 20,
    	marginLeft: 15
    }
};